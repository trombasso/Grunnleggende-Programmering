def main():
    # Open file for output
    output = open("Presidents.txt", "w")

    # Write data to the file
    output.write("George Washington\n")
    output.write("John Adams\n")
    output.write("Thomas Jefferson") #Write Thomas Jefferson

    output.close() # Close the output file

main() # Call the main function
