while count < 100:
    print("Programming is fun!")
    count += 1