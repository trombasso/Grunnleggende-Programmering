from KnightTourModel import KnightTourModel

model = KnightTourModel()
print("The path from vertex 0 is ", model.getHamiltonianPath(4))
