import turtle
turtle.showturtle()
turtle.write("Welcome to Python", font=("Times", 12))

# turtle.forward(130)
# 
# turtle.right(90)
# turtle.color("red")
# turtle.forward(50)
# 
# 
# turtle.right(90)
# turtle.color("green")
# turtle.forward(130)
# 
# turtle.right(45)
# turtle.forward(80)

turtle.done()